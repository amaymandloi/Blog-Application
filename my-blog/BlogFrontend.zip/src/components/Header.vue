<template>
  <div class="header">
    <a style="color: #f3f3f3" href="/login"
      ><h3>Welcome to my blog application</h3></a
    >
    <h3></h3>
  </div>
</template>
<script>
export default {};
</script>
<style>
.header {
  background-color: #265984;
  height: 50px;
}
.header h3 {
  text-align: center;
}
</style>
