module.exports = {
  dev: {
    PORT: 8000,
    HOST: "localhost",
  },
  prod: {
    PORT: 8000,
    HOST: "localhost",
  },

  auth: {
    JWT_SECRET_KEY: "pqowieuryt1092837465",

    TOKEN_HEADER_KEY: "laksjdhfgg6574839201",
  },
};
